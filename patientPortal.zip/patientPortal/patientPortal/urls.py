"""
Definition of urls for patientPortal.
"""

from datetime import datetime
from django.urls import path
from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from app import forms, views
from app import views as app_views
from app.views import index, appointments, contact
from django.conf.urls import include, url

urlpatterns = [
    path('', views.index, name='index'),
    path('healthProfile/', views.healthProfile, name='healthProfile'),
    path('contact/', views.contact, name='contact'),
    path('appointments/', views.appointments, name='appointments'),
    path('logout/', LogoutView.as_view(next_page='/'), name='logout'),
    url(r"^admin/", admin.site.urls),
    url(r"^", include("app.urls")),
]
