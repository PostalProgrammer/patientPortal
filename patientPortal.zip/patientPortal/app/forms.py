"""
Definition of forms.
"""

from django import forms
from . import models
from django.contrib import auth
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth import get_user_model

User = get_user_model()

class PatientRegistration(UserCreationForm):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other')
        ]

    birthdate = forms.DateField(widget=forms.widgets.DateInput(attrs={'type': 'date'}))
    gender = forms.CharField(label = "Gender:", widget = forms.Select(choices = GENDER_CHOICES))
    
    fields = ('first_name', 'last_name', 'email', 'birthdate', 'gender', 'allergies', 'username')

class DoctorRegistration(UserCreationForm):
    birthdate = forms.DateField(widget=forms.widgets.DateInput(attrs={'type': 'date'}))
    fields = ('first_name', 'last_name', 'username')


