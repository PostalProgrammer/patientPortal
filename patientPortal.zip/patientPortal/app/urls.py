from django.conf.urls import url, include
from app.views import index, registerPatient, registerDoctor

urlpatterns = [
    url(r"^accounts/", include("django.contrib.auth.urls")),
    url(r"^index/", index, name="index"),
    url(r"^registerPatient/", registerPatient, name="registerPatient"),
    url(r"^registerDoctor/", registerDoctor, name="registerDoctor"),
]
