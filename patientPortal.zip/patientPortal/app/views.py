"""
Definition of views.
"""

from django.contrib.auth import authenticate, login
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from datetime import datetime
from django.http import HttpRequest
from django.shortcuts import render, redirect
from . import forms
from django.contrib import auth

User = get_user_model()

def index(request):
    """Renders the home page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/index.html',
        {
            'title':'Home Page',
            'year':datetime.now().year,
        }
    )

def contact(request):
    """Renders the contact page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/contact.html',
        {
            'title':'Contact',
            'message':'Your contact page.',
            'year':datetime.now().year,
        }
    )

def appointments(request):
    """Renders the bookings page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/appointments.html',
        {
            'title':'Appointments',
            'message':'Where you can search for/book appointemnts.',
            'year':datetime.now().year,
        }
    )

def registerPatient(request):
    
    if request.method == "GET":
        form = forms.PatientRegistration(request.GET)
        return render(
        request, "app/registerPatient.html",
        {"form": form}
        )
    elif request.method == "POST":
        form = forms.PatientRegistration(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect(reverse("index"))

def registerDoctor(request):
    
    if request.method == "GET":
        form = forms.DoctorRegistration(request.GET)
        return render(
        request, "app/registerDoctor.html",
        {"form": form}
        )
    elif request.method == "POST":
        form = forms.DoctorRegistration(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect(reverse("index"))

def healthProfile(request):
    """Renders the Health Profile page."""
    assert isinstance(request, HttpRequest)
    return render(
        request,
        'app/healthProfile.html',
        {
            'title':'Health Profile',
            'message':'Where you can view your health record.',
            'year':datetime.now().year,
        }
    )
