"""
Definition of models.
"""
#from django.contrib.auth import get_user_model
from django.contrib.auth.models import AbstractUser
from django.db import models
from django import forms
from django.contrib import auth

#User = get_user_model()

# Create your models here.


class User(AbstractUser):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
   
class Patient(User):
    birthdate = models.DateTimeField(auto_now=False, null=True, blank=False)
    gender = models.CharField(max_length=100, blank=False)
    allergies = models.TextField(blank=True)

class PatientHealth(User):
    #patientId
    #doctorId
    #dateTime
    weight = models.CharField(max_length=10)
    bp = models.CharField(max_length=10)

class Doctor(User):
    birthdate = models.DateTimeField(auto_now=False, null=True, blank=False, default=False)

#class Appointments(models.Model):#(uniqueKey)
    #patientId
    #doctorId
    #date/time
   # name = models.CharField(max_length=100)
    #time = models.DateTimeField()